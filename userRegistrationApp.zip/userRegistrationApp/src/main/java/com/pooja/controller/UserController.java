package com.pooja.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pooja.service.UserService;
import com.user.model.User;

@RestController
public class UserController {
	@Autowired
    private UserService userService;

    @Autowired
	PasswordEncoder encoder;
	
	@PostMapping("/registration")
    public String registration(@RequestBody User user) {
        try{
        userService.save(user);
        }catch(Exception ex){
           return "Error in registration. Please try again!!!";
        }
        return "registration";
    }

    //testing
    @GetMapping("/getUsers")
    public List<User> getUsers(){
        return userService.getUsers();
    }
	
	
}

