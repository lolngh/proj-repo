package com.pooja.service;

import java.util.List;

import com.user.model.User;

public interface UserService {
	void save(User user);

    User findByUsername(String username);

    List<User> getUsers();
}