package com.user.model.dto;

public class DataDTO {

    private String id;
    private String deletehash;
    
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getDeletehash() {
        return deletehash;
    }
    public void setDeletehash(String deletehash) {
        this.deletehash = deletehash;
    }

}
